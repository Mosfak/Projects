
function myFunction() {
         document.getElementById("demo").innerHTML =document.getElementById("demo").innerHTML+ "<input type='text'> <br>";
   
        } 
 